/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;
import static VIEW.login_GUI.password;
import static VIEW.login_GUI.user;
import javax.swing.JOptionPane;
import javax.swing.JTextField;



public class aprovacao_DAO {
        
}


